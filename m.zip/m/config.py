import telebot
from telebot import types

admin = 5893628848

chat_logi_error = 5893628848

id_key_payok = 355

api_key_payok = 'cc51737ac9836fc9f295e9189b014e4f'

bot_osnova_token = '5616794289:AAE-dFO8qZRwydbbZMWOiXHv1NWFkrFRLpU'
bot_osnova_name = 'HzBotOsnoVa'
bot_auch_token = '6051886305:AAEvNx9dPVr03fsaho-BAC_t4k9VjwCKOnM'
bot_auch_name = 'HzBotAuch'
bot_logi_token = '5764809787:AAEmtpZfnYDXp0AAQ2Mu244wOhKod2fDpeU'
bot_logi_name = 'HzBotLogi'
bd_host = '176.124.198.11'
bd_login = 'a0599133_gg'
bd_pass = 'nO3CMrgh'
bd_base = 'a0599133_gg'
