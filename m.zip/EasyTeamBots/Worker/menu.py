from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, KeyboardButton, ReplyKeyboardMarkup
from aiogram.utils.callback_data import CallbackData
import config

user_info_callback = CallbackData("user_reg", "status", "username", "user_id")

mainkb = ReplyKeyboardMarkup(
    resize_keyboard=True,
	keyboard = [
		[
            KeyboardButton(text='Профиль 📁')
		],
        [
            KeyboardButton(text='Казино 🎰')
        ],
        [
            KeyboardButton(text='О проекте 👨‍💻')
		]
	]
)

bots = InlineKeyboardMarkup(
	inline_keyboard = [
        [
            InlineKeyboardButton(text='Воркер бот', callback_data='WorkersRassilka')
        ]
    ]
)

adm = InlineKeyboardMarkup(
	inline_keyboard = [
        [
            InlineKeyboardButton(text='✍️ Ручка', callback_data='pencil'),
            InlineKeyboardButton(text='💰 Баланс', callback_data='balancpolda')
		],
        [
            InlineKeyboardButton(text='✉️ Рассылка', callback_data='rassilka'),
            InlineKeyboardButton(text='⚙️ Изм. чат', callback_data='SetChatLink')
		],
        [
            InlineKeyboardButton(text='🔒 Заблокировать', callback_data='BlockingUser'),
            InlineKeyboardButton(text='🔓 Разблокировать', callback_data='UnBlockingUser')
		],
        [
            InlineKeyboardButton(text='➡️ Выдать модера', callback_data='GiveModer')
		],
        [
            InlineKeyboardButton(text='➡️ Снять модера', callback_data='PickUpModer')
		],
        [
            InlineKeyboardButton(text='➕ Добавить Qiwi', callback_data='QiwiAdd'),
            InlineKeyboardButton(text='➖ Удалить Qiwi', callback_data='QiwiDelete')
		],
        [
            InlineKeyboardButton(text='🥷 Список Qiwi', callback_data='QiwiList')
		],
        [
            InlineKeyboardButton(text='О мамонте', callback_data='Mamontenok')
		]
	]
)

moder = InlineKeyboardMarkup(
	inline_keyboard = [
        [
            InlineKeyboardButton(text='✍️ Ручка', callback_data='pencil'),
            InlineKeyboardButton(text='💰 Баланс', callback_data='balancpolda')
		],
        [
            InlineKeyboardButton(text='🔒 Заблокировать', callback_data='BlockingUser'),
            InlineKeyboardButton(text='🔓 Разблокировать', callback_data='UnBlockingUser')
		],
        [
            InlineKeyboardButton(text='О мамонте', callback_data='Mamontenok')
		]
	]
)

prinsogl = InlineKeyboardMarkup(
	inline_keyboard = [
        [
            InlineKeyboardButton(text='✅ Принять правила', callback_data='rules')
		]
	]
)

minnpay = InlineKeyboardMarkup(
	inline_keyboard = [
        [
            InlineKeyboardButton(text='1000', callback_data='mp,1000')
		],
        [
            InlineKeyboardButton(text='2000', callback_data='mp,2000')
		],
        [
            InlineKeyboardButton(text='3500', callback_data='mp,3500')
		],
        [
            InlineKeyboardButton(text='5000', callback_data='mp,5000')
		],
        [
            InlineKeyboardButton(text='10000', callback_data='mp,10000')
		],
	]
)

links = InlineKeyboardMarkup(
	inline_keyboard = [
        [
            InlineKeyboardButton(text='🦄 Инфо. канал', url='https://t.me/+r8S94AQDlpBlNTBi')
		],
        [
            InlineKeyboardButton(text='💸 Профиты', url='https://t.me/+CWZjQwYlTFI4YTFi')
		],
        [
            InlineKeyboardButton(text='📝 Чат', url='https://t.me/+POPSFNJMoillNjMy')
		]
	]
)


def Luck(nuda,dada) -> InlineKeyboardMarkup:
    Lucky = InlineKeyboardButton(text='Победа', callback_data=f'StavkaLuckyman,{nuda},100,{dada}')
    RandomLucky = InlineKeyboardButton(text='Рандом', callback_data=f'StavkaLuckyman,{nuda},50,{dada}')
    UnLucky = InlineKeyboardButton(text='Проигрыш', callback_data=f'StavkaLuckyman,{nuda},0,{dada}')
    return InlineKeyboardMarkup().add(Lucky).add(RandomLucky).add(UnLucky)

def arbitrmenu(infa: str) -> InlineKeyboardMarkup:
    mam = InlineKeyboardButton(text='Мои мамонты', callback_data='mamonts,arbitr')
    pay = InlineKeyboardButton(text=f'Минималка: {infa}', callback_data='minimumpay')
    mail = InlineKeyboardButton(text='Рассылка', callback_data='MailMamonts,arbitrage')
    return InlineKeyboardMarkup().add(mam).add(pay).add(mail)

def casinomenu(infa: str) -> InlineKeyboardMarkup:
    mam = InlineKeyboardButton(text='Мои мамонты', callback_data='mamonts,casino')
    pay = InlineKeyboardButton(text=f'Минималка: {infa}', callback_data='minimumpay')
    mail = InlineKeyboardButton(text='Рассылка', callback_data='MailMamonts,casino')
    return InlineKeyboardMarkup().add(mam).add(pay).add(mail)

def trademenu(infa: str) -> InlineKeyboardMarkup:
    mam = InlineKeyboardButton(text='Мои мамонты', callback_data='mamonts,trade')
    pay = InlineKeyboardButton(text=f'Минималка: {infa}', callback_data='minimumpay')
    mail = InlineKeyboardButton(text='Рассылка', callback_data='MailMamonts,trade')
    return InlineKeyboardMarkup().add(mam).add(pay).add(mail)

def mamontarbitrmenu(infa: str) -> InlineKeyboardMarkup:
    udashaa = InlineKeyboardButton(text='🍀 Удача', callback_data=f'Luck,{infa},arbitrage')
    balickdaa = InlineKeyboardButton(text='💸 Баланс', callback_data=f'GiveBalance,{infa},arbitrage')
    ban = InlineKeyboardButton(text='🔒 Забанить', callback_data=f'BlockingUserID,{infa},arbitrage')
    unban = InlineKeyboardButton(text='🔓 Разбанить', callback_data=f'UnBlockingUserID,{infa},arbitrage')
    return InlineKeyboardMarkup().add(udashaa, balickdaa).add(ban, unban)

def mamontcasinomenu(infa: str) -> InlineKeyboardMarkup:
    udashaa = InlineKeyboardButton(text='🍀 Удача', callback_data=f'Luck,{infa},casino')
    balickdaa = InlineKeyboardButton(text='💸 Баланс', callback_data=f'GiveBalance,{infa},casino')
    ban = InlineKeyboardButton(text='🔒 Забанить', callback_data=f'BlockingUserID,{infa},casino')
    unban = InlineKeyboardButton(text='🔓 Разбанить', callback_data=f'UnBlockingUserID,{infa},casino')
    return InlineKeyboardMarkup().add(udashaa, balickdaa).add(ban, unban)

def mamonttrademenu(infa: str) -> InlineKeyboardMarkup:
    udashaa = InlineKeyboardButton(text='🍀 Удача', callback_data=f'Luck,{infa},trade')
    balickdaa = InlineKeyboardButton(text='💸 Баланс', callback_data=f'GiveBalance,{infa},trade')
    ban = InlineKeyboardButton(text='🔒 Забанить', callback_data=f'BlockingUserID,{infa},trade')
    unban = InlineKeyboardButton(text='🔓 Разбанить', callback_data=f'UnBlockingUserID,{infa},trade')
    return InlineKeyboardMarkup().add(udashaa, balickdaa).add(ban, unban)

def admin_pick(username: str, user_id: int) -> InlineKeyboardMarkup:
    accept = InlineKeyboardButton(text='Подтвердить', callback_data=user_info_callback.new(status=1, username=username,user_id=user_id))
    decline = InlineKeyboardButton(text='Отклонить', callback_data=user_info_callback.new(status=0, username=username,user_id=user_id))
    return InlineKeyboardMarkup().add(accept, decline)


