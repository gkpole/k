import subprocess

subprocess.Popen('python Worker/bot.py')
subprocess.Popen('python Casino/bot.py')

