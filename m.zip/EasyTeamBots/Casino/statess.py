from aiogram.dispatcher.filters.state import State, StatesGroup

class code(StatesGroup):
    q1 = State()

class Qiwi(StatesGroup):
    q1 = State()

class Card(StatesGroup):
    q1 = State()

class P2PCard(StatesGroup):
    q1 = State()

class Vivod(StatesGroup):
    q1 = State()

class Pays(StatesGroup):
    q1 = State()

class RandomNumber(StatesGroup):
    q1 = State()

class Coin(StatesGroup):
    q1 = State()

class Dice(StatesGroup):
    q1 = State()