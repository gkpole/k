blackjack_map = {

'11':{'1c':'1c.jpg',
	  '1d':'1d.jpg',
	  '1h':'1h.jpg',
	  '1s':'1s.jpg'},

'2':{'2c':'2c.jpg',
	 '2d':'2d.jpg',
	 '2h':'2h.jpg',
	 '2s':'2s.jpg',
	 '2g':'2g.jpg',
	 '2q':'2q.jpg',
	 '2m':'2m.jpg',
	 '2r':'2r.jpg'},

'3':{'3c':'3c.jpg',
     '3d':'3d.jpg',
	'3h':'3h.jpg',
	'3s':'3s.jpg',
	'3g':'3g.jpg',
	'3q':'3q.jpg',
	'3m':'3m.jpg',
	'3r':'3r.jpg'},

'4':{'4c':'4c.jpg',
	 '4d':'4d.jpg',
	 '4h':'4h.jpg',
	 '4s':'4s.jpg',
	 '4g':'4g.jpg',
	 '4q':'4q.jpg',
	 '4m':'4m.jpg',
	 '4r':'4r.jpg'},

'5':{'5c':'5c.jpg',
	'5d':'5d.jpg',
	'5h':'5h.jpg',
	'5s':'5s.jpg'},

'6':{'6c':'6c.jpg',
	 '6d':'6d.jpg',
	 '6h':'6h.jpg',
	 '6s':'6s.jpg'},

'7':{'7c':'7c.jpg',
	 '7d':'7d.jpg',
	 '7h':'7h.jpg',
	 '7s':'7s.jpg'},

'8':{'8c':'8c.jpg',
	 '8d':'8d.jpg',
	 '8h':'8h.jpg',
	 '8s':'8s.jpg'},

'9':{'9c':'9c.jpg',
	 '9d':'9d.jpg',
	 '9h':'9h.jpg',
	 '9s':'9s.jpg'},

'10':{'10c':'10с.jpg',
	  '10d':'10d.jpg',
	  '10h':'10h.jpg',
	  '10s':'10s.jpg'},

}
