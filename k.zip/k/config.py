channel_id = -1001867736684  #id канала (для уведомлений)

parner_channel = -1001867736684  # id канала для выплат партнерам

admin = 5893628848  #id админстратора (для выплат)

chats = -1001867736684 #id чата

link_chat = 'https://t.me/+U_FMVxphkQwyYmRi' #Ссылка на чат

token = '5616794289:AAE-dFO8qZRwydbbZMWOiXHv1NWFkrFRLpU' #токен бота

username_bot = '@Cndksppwodkdbot'

news_link = 'http://t.me/noziss'

admin_link = 'https://t.me/noziss'