from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery, Message

from config import config
from data.functions.db import get_user, add_stat, select_buy_stat, update_balance, delete_stat
from keyboards.inline.other_keyboards import check_menu, back_to_main_menu, cabinet_keyboard
from loader import dp, bot
from states.states import balance_states
from texts import cabinet_text
from utils.qiwi import balance, check_payment


@dp.callback_query_handler(text="back_to_personal_account", state="*")
async def back_to_personal_account(call: CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.edit_text(cabinet_text(get_user(call.from_user.id)),
                                 reply_markup=cabinet_keyboard())


@dp.callback_query_handler(text="qiwi_method_balance")
async def add_balance_main(call: CallbackQuery):
    await call.message.edit_text("Напишите сумму, которую вы хотите пополнить."
                                 "\n❗️*Внимание*❗️\n`Минимальная сумма пополнения - 10₽`",
                                 parse_mode="MarkDown", reply_markup=back_to_main_menu)
    await balance_states.BS1.set()


@dp.message_handler(state=balance_states.BS1)
async def add_balance_2(message: Message):
    balance_to_add = message.text
    if int(balance_to_add) >= 10:
        user = (get_user(message.from_user.id))
        add_stat(message.from_user.id, balance_to_add, await balance())
        await bot.send_message(message.chat.id,
                               f"*Для того, чтобы пополнить свой баланс на {balance_to_add}руб вам нужно:*\n\n"
                               f"💰Перевести - `{balance_to_add}₽`\n"
                               f"💳На кошелек - `+{config('QIWI_ADDRESS')}`\n📃С коментарием - `{message.from_user.id}`",
                               parse_mode="MarkDown",
                               reply_markup=await check_menu(balance_to_add, message.from_user.id))
        await balance_states.next()
    else:
        await message.answer("Неверное количество, попробуйте еще раз :)")


@dp.callback_query_handler(text="check", state=balance_states.BS2)
async def add_balance_main(call: CallbackQuery, state: FSMContext):
    n = select_buy_stat(call.from_user.id)
    if await check_payment(call.from_user.id, n[1], n[2]):
        update_balance(call.from_user.id, int(n[1]))
        await call.message.edit_text("<b>Готово, платеж получен, баланс начислен ✅</b>", parse_mode="HTML")
        await bot.send_message(-1001696802165,  f"""▪️{message.from_user.get_mention()}▪️
Новое пополнение баланса""")
        delete_stat(call.from_user.id)
        await state.finish()
    else:
        await call.message.answer("Я еще не получил оплаты")
