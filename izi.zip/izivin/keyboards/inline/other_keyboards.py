from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from config import config


def cabinet_keyboard():
    keyboard = InlineKeyboardMarkup()
    button1 = InlineKeyboardButton(text="📥Пополнить📥", callback_data="deposit")
    button2 = InlineKeyboardButton(text="📤Вывести📤", callback_data="output")
    keyboard.row(button1, button2)

    return keyboard


def deposit_keyboard():
    keyboard = InlineKeyboardMarkup()
    button2 = InlineKeyboardButton(text="🥝QIWI", callback_data="qiwi_method_balance")
    button3 = InlineKeyboardButton(text="👨🏻‍💻Через поддержку", url="t.me/SyltanFRK")
    button1 = InlineKeyboardButton(text="₿ Banker", callback_data="deposit:banker")
    keyboard.row(button3,button2,button1)

    return keyboard


def output_keyboard():
    keyboard = InlineKeyboardMarkup()
    button1 = InlineKeyboardButton(text="🥝 Qiwi", callback_data="output:qiwi")
    button2 = InlineKeyboardButton(text="₿ Banker", callback_data="output:banker")
    button3 = InlineKeyboardButton(text="❌ Отмена", callback_data="output:cancel")
    keyboard.row(button1, button2)
    keyboard.row(button3)

    return keyboard

def p2p_deposit_keyboard(bill_id, url):
    keyboard = InlineKeyboardMarkup(row_width=2)
    keyboard.add(
        InlineKeyboardButton(text='💸 Оплатить 💸', url=url))
    keyboard.add(
        InlineKeyboardButton(text='🔁 Проверить платёж', callback_data=f'check_p2p_deposit:{bill_id}'),
        InlineKeyboardButton(text='❌ Отменить', callback_data=f'reject_p2p_payment')
        )
    return keyboard


async def check_menu(cost, user_id):
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="↗️Перейти к оплате", url=f"https://qiwi.com/payment/form/99?"
                                                                    f"extra%5B%27account%27%5D="
                                                                    f"{config('QIWI_ADDRESS')}&amountInteger="
                                                                    f"{cost}&amountFraction=0&"
                                                                    f"extra%5B%27comment%27%5D="
                                                                    f"{user_id}&currency=643&blocked[0]=account&"
                                                                    f"blocked[1]=comment&blocked[2]=sum")
            ],
            [
                InlineKeyboardButton(text="✅Проверить оплату", callback_data="check")
            ],
            [
                InlineKeyboardButton(text="⬅️Назад", callback_data="back_to_main_menu")
            ]
        ]
    )
    return markup


back_to_main_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="⬅️Назад", callback_data="back_to_personal_account")
        ]
    ]
)

rate_button = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="🤩Отзывы🤩", url="https://t.me/+K0sVRqEHCE9hNmMx")
        ]
    ]
)

support_button = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="🧑‍💻 Админ", url="https://t.me/SyltanFRK")
        ]
    ]
)

chat_button = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="💬CHAT💬", url="https://t.me/+K0sVRqEHCE9hNmMx")
        ]
    ]
)

